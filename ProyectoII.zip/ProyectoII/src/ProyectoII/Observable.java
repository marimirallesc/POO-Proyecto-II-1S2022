package ProyectoII;

/**
 *
 * @author Mari
 */
public class Observable {
    
}
