package ProyectoII;

/**
 *
 * @author Mari
 */
public class Observer {
    
}
